# Presidential OS

Custom Fedora-based OS with controller-first UI.